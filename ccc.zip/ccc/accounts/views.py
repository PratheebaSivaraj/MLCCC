from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User,auth
from django.conf import settings
from django.core.mail import send_mail
import pandas as pd

def Login(request):
    if request.method=="POST":
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect("home")
        else:
            messages.info(request,"invalid credentials")
            return redirect("Login")
    else:
        return render(request,'accounts/login.html')
def register(request):
    
    if request.method == "POST":
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['psw']
        psw_repeat=request.POST['psw-repeat']
        if password==psw_repeat:
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username Taken')
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request,'emailid exists')
                return redirect('register')
            else:
                
                subject='Message from Credit card Fraud detection'
                message='Thank for Login...'
                emailFrom=settings.EMAIL_HOST_USER
                emailTo=[request.POST['email']]
                a=send_mail(subject,message,emailFrom,emailTo,fail_silently=False)
                if(a==1):
                    user=User.objects.create_user(username=username,email=email,password=password)#https://myaccount.google.com/u/1/security
                    user.save()
                    return redirect('Login')
                else:
                    messages.info(request,'invalid e-mail')
                
        else:
            messages.info(request,'passsword mismatch')
            return redirect('register')
        return redirect('Login')
        
        
    else:
        return render(request,'accounts/register.html')
def logout_page(request):
    auth.logout(request)
    return redirect("Login")
def home(request):
    if "POST" == request.method:
        csv_file = request.FILES["csv_file"]
        if not csv_file.name.endswith('.csv'):
            messages.info(request,'File is not CSV type')
            return redirect('home')
        """
        #if file is too large, return message
        if csv_file.multiple_chunks():
            messages.info(request,"Uploaded file is too big (%.2f MB)." % (csv_file.size/(10000*10000),))
            return redirect('home')
        """
        creditcard = pd.read_csv(csv_file)
        print(creditcard.head())
        return redirect('home')
    else:
        return render(request,'accounts/index.html')

    